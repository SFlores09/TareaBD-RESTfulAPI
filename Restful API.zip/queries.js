const dbconfig = require('./dbconfig')

const Pool = require('pg').Pool

const pool = new Pool(dbconfig.dbconfig)

/////////////////////////////////////////////////  Sucursales  /////////////////////////////////////////////////
const getSucursales = (request, response) => {
    pool.query('SELECT * FROM sucursal', (error, results) => {
      if (error) {
         response.json({ info: 'Error: No se encontraron sucursales' })
      }
      else{
          response.status(200).json(results.rows)
      }
    })
  }

  const getSucursalesByID = (request, response) => {

    const idSucursal = parseInt(request.params.id)

    pool.query('SELECT * FROM sucursal WHERE idsucursal= $1',
    [idSucursal], (error, results) => {
      if (error) {
         response.json({ info: 'Error: No se encontraron sucursales' })
      }
      else{
          response.status(200).json(results.rows)
      }
    })
  }

  const createSucursales = (request, response) => {
    const { direccionSucursal } = request.body
  
    pool.query('INSERT INTO sucursal (direccionsucursal) VALUES ($1)',
     [direccionSucursal],
      (error, results) => {
      if (error) {
         response.json({ info: 'Error al crear una sucursal' })
      }
      else{
        response.status(201).send(`Sucursal agregada`)
      }
    })
  }

  const updateSucursales = (request, response) => {
    const { direccionSucursal, idSucursal } = request.body
  
    pool.query(
      'UPDATE Sucursal SET direccionsucursal = $1 WHERE idSucursal = $2',
      [direccionSucursal, parseInt(idSucursal)],
      (error, results) => {
      if (error) {
         response.json({ info: 'Error al actualizar sucursal' })
      }
      else{
        response.status(200).send(`Sucursal modificada correctamente. SucursalID: ${idSucursal}`)
      }
      }
    )
  }

  const deleteSucursales = (request, response) => {
    const {idSucursal} = request.body
  
    pool.query('DELETE FROM Sucursal WHERE idSucursal = $1', 
      [parseInt(idSucursal)], 
      (error, results) => {
      if (error) {
         response.json({ info: 'Error al eliminar Sucursal' })
      }
      else{
        response.status(200).send(`Sucursal eliminada. SucursalID: ${idSucursal}`)
      }
    })
  }


  /////////////////////////////////////////////////  Departamentos  /////////////////////////////////////////////////
  const getDepartamentos = (request, response) => {
    pool.query('SELECT * FROM Departamento', (error, results) => {
      if (error) {
         response.json({ info: 'Error: No se encontraron Departamento' })
      }
      else{
          response.status(200).json(results.rows)
      }
    })
  }


  const getDepartamentosByID = (request, response) => {

    const idDepartamento = parseInt(request.params.id)

    pool.query('SELECT * FROM Departamento WHERE iddepartamento = $1',
    [idDepartamento], (error, results) => {
      if (error) {
         response.json({ info: 'Error: No se encontraron Departamento' })
      }
      else{
          response.status(200).json(results.rows)
      }
    })
  }
  
  const createDepartamentos = (request, response) => {
    const { nombreDepartamento, descripcionDepartamento, idSucursal } = request.body
  
    pool.query('INSERT INTO Departamento (nombredepartamento, descripciondepartamento, idsucursal) VALUES ($1, $2, $3)',
    [nombreDepartamento, descripcionDepartamento, idSucursal],
      (error, results) => {
      if (error) {
         response.json({ info: 'Error al crear departamento' })
      }
      else{
        response.status(201).send(`Departamento agregado correctamente`)
      }
    })
  }

  const updateDepartamentos = (request, response) => {
    const { nombreDepartamento, descripcionDepartamento, idSucursal, idDepartamento } = request.body
  
    pool.query(
      'UPDATE Departamento SET nombreDepartamento = $1, descripcionDepartamento = $2, idSucursal = $3 WHERE idDepartamento = $4',
      [nombreDepartamento, descripcionDepartamento, idSucursal, parseInt(idDepartamento)],
      (error, results) => {
      if (error) {
         response.json({ info: 'Error al actualizar departamento' })
      }
      else{
        response.status(200).send(`Departamento modificado. DepartamentoID: ${idDepartamento}`)
      }
      }
    )
  }

  const deleteDepartamentos = (request, response) => {
    const {idDepartamento} = request.body
  
    pool.query('DELETE FROM Departamento WHERE idDepartamento = $1', 
      [parseInt(idDepartamento)], 
      (error, results) => {
      if (error) {
         response.json({ info: 'Error al eliminar departamento' })
      }
      else{
        response.status(200).send(`Departamento eliminado. DepartamentoID: ${idDepartamento}`)
      }
    })
  }



  ///////////////////////////////////////////////// Empleados  /////////////////////////////////////////////////
  const getEmpleados = (request, response) => {
    pool.query('SELECT * FROM Empleado', (error, results) => {
      if (error) {
         response.json({ info: 'Error: No se encontraron Empleado' })
      }
      else{
          response.status(200).json(results.rows)
      }
    })
  }

  const getEmpleadosByID = (request, response) => {

    const idEmpleado = parseInt(request.params.id)

    pool.query('SELECT * FROM Empleado WHERE idempleado = $1',
    [idEmpleado], (error, results) => {
      if (error) {
         response.json({ info: 'Error: No se encontraron Empleado' })
      }
      else{
          response.status(200).json(results.rows)
      }
    })
  }


  const createEmpleados = (request, response) => {
    const { nombre, apellido, fechaNacimiento, fechaIngreso, idDepartamento } = request.body
  
    pool.query('INSERT INTO Empleado (nombre, apellido, fechanacimiento, fechaingreso, iddepartamento) VALUES ($1, $2, $3, $4, $5)',
     [nombre, apellido, fechaNacimiento, fechaIngreso, parseInt(idDepartamento)],
      (error, results) => {
      if (error) {
         response.json({ info: 'Error al crear empleado' })
      }
      else{
        response.status(201).send(`Empleado agregado con éxito`)
      }
    })
  }

  const updateEmpleados = (request, response) => {
    const { nombre, apellido, fechaNacimiento, fechaIngreso, idEmpleado, idDepartamento} = request.body

    pool.query(
      'UPDATE Empleado SET nombre = $1, apellido = $2, fechanacimiento = $3, fechaingreso=$4, iddepartamento=$5 WHERE idEmpleado = $6',
      [nombre, apellido, fechaNacimiento, fechaIngreso, parseInt(idDepartamento), parseInt(idEmpleado)],
      (error, results) => {
      if (error) {
         response.json({ info: 'Error actualizando empleado' })
      }
      else{
        response.status(200).send(`Empleado actualizado. EmpleadoID: ${idEmpleado}`)
      }
      }
    )
  }

  const deleteEmpleados = (request, response) => {
    const {idEmpleado} = request.body
  
    pool.query('DELETE FROM Empleado WHERE idEmpleado = $1', 
      [parseInt(idEmpleado)], 
      (error, results) => {
      if (error) {
         response.json({ info: 'Error eliminando empleado' })
      }
      else{
        response.status(200).send(`Empleado eliminado. EmpleadoID: ${idEmpleado}`)
      }
    })
  }



  module.exports = {
    getSucursales,
    getSucursalesByID,
    createSucursales,
    updateSucursales,
    deleteSucursales,

    getDepartamentos,
    getDepartamentosByID,
    createDepartamentos,
    updateDepartamentos,
    deleteDepartamentos,
    
    getEmpleados,
    getEmpleadosByID,
    createEmpleados,
    updateEmpleados,
    deleteEmpleados
  }