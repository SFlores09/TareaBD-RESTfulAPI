const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const db = require('./queries')
const port = 5000

app.use(bodyParser.json())
app.use(
    bodyParser.urlencoded({
        extended: true,
    })
)

app.get('/', (request, response) => { 
    response.json({ info: 'Node.js, Express, and Postgres API' }) 
})



app.get('/Sucursales', db.getSucursales)
app.get('/Departamentos', db.getDepartamentos)
app.get('/Empleados', db.getEmpleados)

app.get('/Sucursales/:id', db.getSucursalesByID)
app.get('/Departamentos/:id', db.getDepartamentosByID)
app.get('/Empleados/:id', db.getEmpleadosByID)

app.post('/Sucursales',db.createSucursales)
app.post('/Departamentos',db.createDepartamentos)
app.post('/Empleados',db.createEmpleados)

app.put('/Sucursales',db.updateSucursales)
app.put('/Departamentos',db.updateDepartamentos)
app.put('/Empleados',db.updateEmpleados)

app.delete('/Sucursales/',db.deleteSucursales)
app.delete('/Departamentos/',db.deleteDepartamentos)
app.delete('/Empleados/',db.deleteEmpleados)




app.listen(port, () => { 
    console.log(`App running on port ${port}.`)
})
