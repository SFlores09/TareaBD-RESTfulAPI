exports.dbconfig = {
    user: 'postgres',
    host: 'localhost',
    database: 'Prueba1',
    password: 'contraseña',
    port: 5432,
};
